# Submission Guide

## Final Deliverables

Use these files for submission:

- Google Sheets-ready dashboard workbook: `outputs/google_sheets_dashboard/osmi_mental_health_google_sheets_dashboard.xlsx`
- Analysis notebook with chart snippets: `notebooks/osmi_mental_health_analysis.ipynb`
- Report chart assets: `outputs/report_chart_assets/`
- Supplementary HTML dashboard: `outputs/dashboard/osmi_mental_health_dashboard.html`
- Written report DOCX: `outputs/osmi_mental_health_written_report_upload_ready.docx`
- Written report PDF preview: `outputs/osmi_mental_health_written_report_upload_ready.pdf`
- Presentation PPTX: `outputs/presentation/osmi_mental_health_capstone_presentation.pptx`
- Presentation PDF preview: `outputs/presentation/osmi_mental_health_capstone_presentation.pdf`
- Speaker notes: `outputs/presentation/osmi_mental_health_speaker_notes.md`
- Full submission package: `outputs/data_analytics_capstone_submission_package.zip`

The ZIP package contains the report DOCX/PDF, Google Sheets-ready dashboard workbook, chart assets, supplementary dashboard HTML, presentation PPTX/PDF, speaker notes, notebook, README, submission guide, and final review checklist.

## Google Docs Report

If the platform requires a Google Docs link:

1. Upload `outputs/osmi_mental_health_written_report_upload_ready.docx` to Google Drive.
2. Open it with Google Docs.
3. Check that the title, headings, bullets, and references imported correctly.
4. Rename the Google Doc:
   - `Workplace Mental Health Disclosure And Support In The Technology Sector - Written Report`
5. Share the document according to the platform instructions.

The DOCX was visually checked by exporting it to PDF and reviewing all 7 rendered pages.

## Google Slides Presentation

If the platform requires a Google Slides link:

1. Upload `outputs/presentation/osmi_mental_health_capstone_presentation.pptx` to Google Drive.
2. Open it with Google Slides.
3. Check that all 11 slides imported correctly.
4. Check speaker notes. If notes do not import cleanly, use `outputs/presentation/osmi_mental_health_speaker_notes.md` to paste them manually.
5. Rename the deck:
   - `Workplace Mental Health Disclosure And Support In The Technology Sector - Presentation`
6. Share the deck according to the platform instructions.

The PPTX was checked by exporting it to an 11-page PDF and rendering all 11 slides as preview images.

## Dashboard

The primary dashboard deliverable should be the Google Sheets-ready workbook:

- `outputs/google_sheets_dashboard/osmi_mental_health_google_sheets_dashboard.xlsx`

Recommended submission path:

1. Upload the XLSX workbook to Google Drive.
2. Open it with Google Sheets.
3. Check that the `Dashboard` sheet, KPI blocks, charts, and source tabs imported correctly.
4. Rename it:
   - `Workplace Mental Health Disclosure And Support - Dashboard`
5. Share the Google Sheets link according to the platform instructions.

The written report also contains all six key chart snippets from:

- `outputs/report_chart_assets/`

The standalone HTML dashboard is supplementary:

- `outputs/dashboard/osmi_mental_health_dashboard.html`

It contains embedded Plotly JavaScript, so it can be opened directly in a browser without a separate server.

Upload the notebook as a supporting reproducible analysis artifact if the platform allows extra files. Upload the HTML dashboard only as a supplementary visual file.

If the platform requires a public link, possible options are:

- GitHub Pages
- Netlify drop
- Google Drive file link, if HTML preview is accepted
- A portfolio repository with the dashboard saved as an artifact

## Suggested Submission Summary

This capstone analyzes the OSMI Mental Health in Tech Survey to study treatment-seeking, workplace support, work interference, perceived consequences, and mental health disclosure comfort among technology-sector respondents. The project uses segmentation, hypothesis testing, and logistic regression/classification modeling. The main finding is that treatment-seeking is common in the sample, but workplace disclosure comfort is much lower, especially with coworkers. The analysis is observational and self-reported, so results are interpreted as associations rather than causal effects.

## Files To Keep For Portfolio

- `README.md`
- `notes/final-review-checklist.md`
- `outputs/osmi_mental_health_written_report_upload_ready.docx`
- `outputs/osmi_mental_health_written_report_upload_ready.pdf`
- `outputs/report_chart_assets/`
- `outputs/google_sheets_dashboard/osmi_mental_health_google_sheets_dashboard.xlsx`
- `outputs/dashboard/osmi_mental_health_dashboard.html`
- `outputs/presentation/osmi_mental_health_capstone_presentation.pptx`
- `outputs/presentation/osmi_mental_health_capstone_presentation.pdf`
- `notebooks/osmi_mental_health_analysis.ipynb`
- `scripts/`
